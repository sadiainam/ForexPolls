@extends('admin.layouts.default')

{{-- Web site Title --}}
@section('title') {!! trans("admin/broker.broker") !!} ::
@parent @stop

@section('styles')
    @parent
    <link href="{{ asset("css/flags.css") }}" rel="stylesheet">
@endsection

{{-- Content --}}
@section('main')
    <div class="page-header">
        <h3>
            {!! trans("admin/broker.brokers") !!}

            <div class="pull-right">
                <a href="{!!  URL::to('admin/broker/create') !!}"
                   class="btn btn-sm  btn-primary iframe"><span
                            class="glyphicon glyphicon-plus-sign"></span> {!!
				trans("admin/modal.new") !!}</a>
            </div>
        </h3>
    </div>

    <table id="table" class="table table-striped table-hover">
        <thead>
        <tr>
            <th>{{ trans("admin/broker.broker_name") }}</th>
            <th>{{ trans("admin/broker.broker_type") }}</th>
            <th>{{ trans("admin/broker.country") }}</th>
            <th>{{ trans("admin/admin.action") }}</th>
        </tr>
        </thead>
        <tbody>
        </tbody>
    </table>
@stop

{{-- Scripts --}}
@section('scripts')
@stop
