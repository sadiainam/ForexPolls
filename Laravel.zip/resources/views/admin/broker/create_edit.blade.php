@extends('admin.layouts.modal')
{{-- Content --}}
@section('content')
        <!-- Tabs -->
<ul class="nav nav-tabs">
    <li class="active"><a href="#tab-general" data-toggle="tab"> {{
			trans("admin/modal.general") }}</a></li>
    <li><a href="#tab-accountoptions" data-toggle="tab"> {{
			trans("admin/broker.account_options") }}</a></li>
    
    <li><a href="#tab-service" data-toggle="tab"> {{
			trans("admin/broker.customer") }}</a></li>
    <li><a href="#tab-trading" data-toggle="tab"> {{
			trans("admin/broker.trading") }}</a></li>
    <li><a href="#tab-account" data-toggle="tab"> {{
			trans("admin/broker.account") }}</a></li>
    <li><a href="#tab-description" data-toggle="tab"> {{
			trans("admin/broker.description") }}</a></li>
</ul>
<!-- ./ tabs -->
@if (isset($broker))
{!! Form::model($broker, array('url' => URL::to('admin/broker') . '/' . $broker->id, 'method' => 'put','id'=>'fupload', 'class' => 'bf', 'files'=> true)) !!}
@else
{!! Form::open(array('url' => URL::to('admin/broker'), 'method' => 'post', 'class' => 'bf','id'=>'fupload', 'files'=> true)) !!}
@endif
        <!-- Tabs Content -->
<div class="tab-content">
    <!-- General tab -->
    <div class="tab-pane active" id="tab-general">
<!--        <div class="form-group  {{ $errors->has('language_id') ? 'has-error' : '' }}">
            {!! Form::label('language_id', trans("admin/admin.language"), array('class' => 'control-label')) !!}
            <div class="controls">
                {!! Form::select('language_id', $languages, @isset($broker)? $broker->language_id : 'default', array('class' => 'form-control')) !!}
                <span class="help-block">{{ $errors->first('language_id', ':message') }}</span>
            </div>
        </div>-->

        <div class="form-group  {{ $errors->has('broker_name') ? 'has-error' : '' }}">
            {!! Form::label('broker_name', trans("admin/broker.broker_name"), array('class' => 'control-label')) !!}
            <div class="controls">
                {!! Form::text('broker_name', null, array('class' => 'form-control')) !!}
                <span class="help-block">{{ $errors->first('broker_name', ':message') }}</span>
            </div>
        </div>
        <div class="form-group  {{ $errors->has('broker_type') ? 'has-error' : '' }}">
            {!! Form::label('broker_type', trans("admin/broker.broker_type"), array('class' => 'control-label')) !!}
            <div class="controls">
               
               {!! Form::select('broker_type', $broker_types, @isset($broker)? $broker->broker_type_id : 'default', array('class' => 'form-control')) !!}
             
                <span class="help-block">{{ $errors->first('broker_type', ':message') }}</span>
            </div>
        </div>
        <div class="form-group  {{ $errors->has('country') ? 'has-error' : '' }}">
            {!! Form::label('country', trans("admin/broker.country"), array('class' => 'control-label')) !!}
            <div class="controls">
                {!! Form::text('country', null, array('class' => 'form-control')) !!}
                <span class="help-block">{{ $errors->first('country', ':message') }}</span>
            </div>
        </div>
        <div class="form-group  {{ $errors->has('operating_year') ? 'has-error' : '' }}">
            {!! Form::label('operating_year', trans("admin/broker.operating_year"), array('class' => 'control-label')) !!}
            <div class="controls">
                {!! Form::text('operating_year', null, array('class' => 'form-control')) !!}
                <span class="help-block">{{ $errors->first('operating_year', ':message') }}</span>
            </div>
        </div>
        <div class="form-group  {{ $errors->has('no_of_employees') ? 'has-error' : '' }}">
            {!! Form::label('no_of_employees', trans("admin/broker.no_of_employees"), array('class' => 'control-label')) !!}
            <div class="controls">
                {!! Form::text('no_of_employees', null, array('class' => 'form-control')) !!}
                <span class="help-block">{{ $errors->first('no_of_employees', ':message') }}</span>
            </div>
        </div>
        <div class="form-group  {{ $errors->has('international_offices') ? 'has-error' : '' }}">
            {!! Form::label('international_offices', trans("admin/broker.international_offices"), array('class' => 'control-label')) !!}
            <div class="controls">
                {!! Form::text('international_offices', null, array('class' => 'form-control')) !!}
                <span class="help-block">{{ $errors->first('international_offices', ':message') }}</span>
            </div>
        </div>
        <div class="form-group  {{ $errors->has('regulation') ? 'has-error' : '' }}">
            {!! Form::label('regulation', trans("admin/broker.regulation"), array('class' => 'control-label')) !!}
            <div class="controls">
                {!! Form::text('regulation', null, array('class' => 'form-control')) !!}
                <span class="help-block">{{ $errors->first('regulation', ':message') }}</span>
            </div>
        </div>
        <div class="form-group  {{ $errors->has('address') ? 'has-error' : '' }}">
            {!! Form::label('address', trans("admin/broker.address"), array('class' => 'control-label')) !!}
            <div class="controls">
                {!! Form::text('address', null, array('class' => 'form-control')) !!}
                <span class="help-block">{{ $errors->first('address', ':message') }}</span>
            </div>
        </div>
        <div class="form-group  {{ $errors->has('broker_status') ? 'has-error' : '' }}">
            {!! Form::label('broker_status', trans("admin/broker.broker_status"), array('class' => 'control-label')) !!}
            <div class="controls">
                {!! Form::text('broker_status', null, array('class' => 'form-control')) !!}
                <span class="help-block">{{ $errors->first('broker_status', ':message') }}</span>
            </div>
        </div>
        <div class="form-group  {{ $errors->has('acception_us_clients') ? 'has-error' : '' }}">
            {!! Form::label('acception_us_clients', trans("admin/broker.acception_us_clients"), array('class' => 'control-label')) !!}
            <div class="controls">
                {!! Form::text('acception_us_clients', null, array('class' => 'form-control')) !!}
                <span class="help-block">{{ $errors->first('acception_us_clients', ':message') }}</span>
            </div>
        </div>
      
<!--        <div class="form-group  {{ $errors->has('content') ? 'has-error' : '' }}">
            {!! Form::label('content', trans("admin/article.content"), array('class' => 'control-label')) !!}
            <div class="controls">
                {!! Form::textarea('content', null, array('class' => 'form-control')) !!}
                <span class="help-block">{{ $errors->first('content', ':message') }}</span>
            </div>
        </div>
        <div class="form-group  {{ $errors->has('source') ? 'has-error' : '' }}">
            {!! Form::label('source', trans("admin/article.source"), array('class' => 'control-label')) !!}
            <div class="controls">
                {!! Form::text('source', null, array('class' => 'form-control')) !!}
                <span class="help-block">{{ $errors->first('source', ':message') }}</span>
            </div>
        </div>
        <div
                class="form-group {!! $errors->has('picture') ? 'error' : '' !!} ">
            <div class="col-lg-12">
                {!! Form::label('source', trans("admin/article.picture"), array('class' => 'control-label')) !!}
                <input name="picture"
                       type="file" class="uploader" id="image" value="Upload"/>
            </div>

        </div>-->
        <!-- ./ general tab -->
    </div>
     <!-- Accounts tab -->
    <div class="tab-pane" id="tab-accountoptions">
        <div class="form-group  {{ $errors->has('account_currency') ? 'has-error' : '' }}">
            {!! Form::label('account_currency', trans("admin/broker.account_currency"), array('class' => 'control-label')) !!}
            <div class="controls">
                {!! Form::text('account_currency', null, array('class' => 'form-control')) !!}
                <span class="help-block">{{ $errors->first('account_currency', ':message') }}</span>
            </div>
        </div>
        <div class="form-group  {{ $errors->has('funding_withdrawl_method') ? 'has-error' : '' }}">
            {!! Form::label('funding_withdrawl_method', trans("admin/broker.funding_withdrawl_method"), array('class' => 'control-label')) !!}
            <div class="controls">
                {!! Form::text('funding_withdrawl_method', null, array('class' => 'form-control')) !!}
                <span class="help-block">{{ $errors->first('funding_withdrawl_method', ':message') }}</span>
            </div>
        </div>
        <div class="form-group  {{ $errors->has('swap_free_accounts') ? 'has-error' : '' }}">
            {!! Form::label('swap_free_accounts', trans("admin/broker.swap_free_accounts"), array('class' => 'control-label')) !!}
            <div class="controls">
                {!! Form::text('swap_free_accounts', null, array('class' => 'form-control')) !!}
                <span class="help-block">{{ $errors->first('swap_free_accounts', ':message') }}</span>
            </div>
        </div><div class="form-group  {{ $errors->has('segregated_accounts') ? 'has-error' : '' }}">
            {!! Form::label('segregated_accounts', trans("admin/broker.segregated_accounts"), array('class' => 'control-label')) !!}
            <div class="controls">
                {!! Form::text('segregated_accounts', null, array('class' => 'form-control')) !!}
                <span class="help-block">{{ $errors->first('segregated_accounts', ':message') }}</span>
            </div>
        </div>
        <div class="form-group  {{ $errors->has('interest_on_margin') ? 'has-error' : '' }}">
            {!! Form::label('interest_on_margin', trans("admin/broker.interest_on_margin"), array('class' => 'control-label')) !!}
            <div class="controls">
                {!! Form::text('interest_on_margin', null, array('class' => 'form-control')) !!}
                <span class="help-block">{{ $errors->first('interest_on_margin', ':message') }}</span>
            </div>
        </div>
        <div class="form-group  {{ $errors->has('managed_accounts') ? 'has-error' : '' }}">
            {!! Form::label('managed_accounts', trans("admin/broker.managed_accounts"), array('class' => 'control-label')) !!}
            <div class="controls">
                {!! Form::text('managed_accounts', null, array('class' => 'form-control')) !!}
                <span class="help-block">{{ $errors->first('managed_accounts', ':message') }}</span>
            </div>
        </div>
        <div class="form-group  {{ $errors->has('accounts_for_money_managers') ? 'has-error' : '' }}">
            {!! Form::label('accounts_for_money_managers', trans("admin/broker.accounts_for_money_managers"), array('class' => 'control-label')) !!}
            <div class="controls">
                {!! Form::text('accounts_for_money_managers', null, array('class' => 'form-control')) !!}
                <span class="help-block">{{ $errors->first('accounts_for_money_managers', ':message') }}</span>
            </div>
        </div>
        
        
    </div>
     <!-- ./ accounts tab -->
     <!-- Customer Service tab -->
     <div class="tab-pane" id="tab-service">
        
           <div class="form-group  {{ $errors->has('phone') ? 'has-error' : '' }}">
            {!! Form::label('phone', trans("admin/broker.phone"), array('class' => 'control-label')) !!}
            <div class="controls">
                {!! Form::text('phone', null, array('class' => 'form-control')) !!}
                <span class="help-block">{{ $errors->first('phone', ':message') }}</span>
            </div>
        </div>
            <div class="form-group  {{ $errors->has('fax') ? 'has-error' : '' }}">
            {!! Form::label('fax', trans("admin/broker.fax"), array('class' => 'control-label')) !!}
            <div class="controls">
                {!! Form::text('fax', null, array('class' => 'form-control')) !!}
                <span class="help-block">{{ $errors->first('fax', ':message') }}</span>
            </div>
        </div>
            <div class="form-group  {{ $errors->has('email') ? 'has-error' : '' }}">
            {!! Form::label('email', trans("admin/broker.email"), array('class' => 'control-label')) !!}
            <div class="controls">
                {!! Form::text('email', null, array('class' => 'form-control')) !!}
                <span class="help-block">{{ $errors->first('email', ':message') }}</span>
            </div>
        </div>
            <div class="form-group  {{ $errors->has('languages') ? 'has-error' : '' }}">
            {!! Form::label('languages', trans("admin/broker.languages"), array('class' => 'control-label')) !!}
            <div class="controls">
                {!! Form::text('languages', null, array('class' => 'form-control')) !!}
                <span class="help-block">{{ $errors->first('languages', ':message') }}</span>
            </div>
        </div>
            <div class="form-group  {{ $errors->has('availability') ? 'has-error' : '' }}">
            {!! Form::label('availability', trans("admin/broker.availability"), array('class' => 'control-label')) !!}
            <div class="controls">
                {!! Form::text('availability', null, array('class' => 'form-control')) !!}
                <span class="help-block">{{ $errors->first('availability', ':message') }}</span>
            </div>
        </div>
         
        
    </div>
     <!-- ./ customer service tab -->
      <!-- Trading tab -->
      <div class="tab-pane" id="tab-trading">
        
             <div class="form-group  {{ $errors->has('trading_platforms') ? 'has-error' : '' }}">
            {!! Form::label('trading_platforms', trans("admin/broker.trading_platforms"), array('class' => 'control-label')) !!}
            <div class="controls">
                {!! Form::text('trading_platforms', null, array('class' => 'form-control')) !!}
                <span class="help-block">{{ $errors->first('trading_platforms', ':message') }}</span>
            </div>
        </div>
             <div class="form-group  {{ $errors->has('trading_platform_timezone') ? 'has-error' : '' }}">
            {!! Form::label('trading_platform_timezone', trans("admin/broker.trading_platform_timezone"), array('class' => 'control-label')) !!}
            <div class="controls">
                {!! Form::text('trading_platform_timezone', null, array('class' => 'form-control')) !!}
                <span class="help-block">{{ $errors->first('trading_platform_timezone', ':message') }}</span>
            </div>
        </div>
             <div class="form-group  {{ $errors->has('demo_account') ? 'has-error' : '' }}">
            {!! Form::label('demo_account', trans("admin/broker.demo_account"), array('class' => 'control-label')) !!}
            <div class="controls">
                {!! Form::text('demo_account', null, array('class' => 'form-control')) !!}
                <span class="help-block">{{ $errors->first('demo_account', ':message') }}</span>
            </div>
        </div>
             <div class="form-group  {{ $errors->has('mobile_trading') ? 'has-error' : '' }}">
            {!! Form::label('mobile_trading', trans("admin/broker.mobile_trading"), array('class' => 'control-label')) !!}
            <div class="controls">
                {!! Form::text('mobile_trading', null, array('class' => 'form-control')) !!}
                <span class="help-block">{{ $errors->first('mobile_trading', ':message') }}</span>
            </div>
        </div>
             <div class="form-group  {{ $errors->has('web_based_trading') ? 'has-error' : '' }}">
            {!! Form::label('web_based_trading', trans("admin/broker.web_based_trading"), array('class' => 'control-label')) !!}
            <div class="controls">
                {!! Form::text('web_based_trading', null, array('class' => 'form-control')) !!}
                <span class="help-block">{{ $errors->first('web_based_trading', ':message') }}</span>
            </div>
        </div>
             <div class="form-group  {{ $errors->has('api') ? 'has-error' : '' }}">
            {!! Form::label('api', trans("admin/broker.api"), array('class' => 'control-label')) !!}
            <div class="controls">
                {!! Form::text('api', null, array('class' => 'form-control')) !!}
                <span class="help-block">{{ $errors->first('api', ':message') }}</span>
            </div>
        </div>
             <div class="form-group  {{ $errors->has('oco_orders') ? 'has-error' : '' }}">
            {!! Form::label('oco_orders', trans("admin/broker.oco_orders"), array('class' => 'control-label')) !!}
            <div class="controls">
                {!! Form::text('oco_orders', null, array('class' => 'form-control')) !!}
                <span class="help-block">{{ $errors->first('oco_orders', ':message') }}</span>
            </div>
        </div>
             <div class="form-group  {{ $errors->has('trading_over_the_phone') ? 'has-error' : '' }}">
            {!! Form::label('trading_over_the_phone', trans("admin/broker.trading_over_the_phone"), array('class' => 'control-label')) !!}
            <div class="controls">
                {!! Form::text('trading_over_the_phone', null, array('class' => 'form-control')) !!}
                <span class="help-block">{{ $errors->first('trading_over_the_phone', ':message') }}</span>
            </div>
        </div>
           <div class="form-group  {{ $errors->has('hedging_allowed') ? 'has-error' : '' }}">
            {!! Form::label('hedging_allowed', trans("admin/broker.hedging_allowed"), array('class' => 'control-label')) !!}
            <div class="controls">
                {!! Form::text('hedging_allowed', null, array('class' => 'form-control')) !!}
                <span class="help-block">{{ $errors->first('hedging_allowed', ':message') }}</span>
            </div>
        </div>
           <div class="form-group  {{ $errors->has('trailing_stops') ? 'has-error' : '' }}">
            {!! Form::label('trailing_stops', trans("admin/broker.trailing_stops"), array('class' => 'control-label')) !!}
            <div class="controls">
                {!! Form::text('trailing_stops', null, array('class' => 'form-control')) !!}
                <span class="help-block">{{ $errors->first('trailing_stops', ':message') }}</span>
            </div>
        </div>
           <div class="form-group  {{ $errors->has('one_click_trading') ? 'has-error' : '' }}">
            {!! Form::label('one_click_trading', trans("admin/broker.one_click_trading"), array('class' => 'control-label')) !!}
            <div class="controls">
                {!! Form::text('one_click_trading', null, array('class' => 'form-control')) !!}
                <span class="help-block">{{ $errors->first('one_click_trading', ':message') }}</span>
            </div>
        </div>
           <div class="form-group  {{ $errors->has('bonuses') ? 'has-error' : '' }}">
            {!! Form::label('bonuses', trans("admin/broker.bonuses"), array('class' => 'control-label')) !!}
            <div class="controls">
                {!! Form::text('bonuses', null, array('class' => 'form-control')) !!}
                <span class="help-block">{{ $errors->first('bonuses', ':message') }}</span>
            </div>
        </div>
           <div class="form-group  {{ $errors->has('contests') ? 'has-error' : '' }}">
            {!! Form::label('contests', trans("admin/broker.contests"), array('class' => 'control-label')) !!}
            <div class="controls">
                {!! Form::text('contests', null, array('class' => 'form-control')) !!}
                <span class="help-block">{{ $errors->first('contests', ':message') }}</span>
            </div>
        </div>
           <div class="form-group  {{ $errors->has('other_trading_instruments') ? 'has-error' : '' }}">
            {!! Form::label('other_trading_instruments', trans("admin/broker.other_trading_instruments"), array('class' => 'control-label')) !!}
            <div class="controls">
                {!! Form::text('other_trading_instruments', null, array('class' => 'form-control')) !!}
                <span class="help-block">{{ $errors->first('other_trading_instruments', ':message') }}</span>
            </div>
        </div>
        
    </div>
     <!-- ./ trading service tab -->
      <!-- Accounts tab -->
      <div class="tab-pane" id="tab-account">
        
           <div class="form-group  {{ $errors->has('minimum_deposit') ? 'has-error' : '' }}">
            {!! Form::label('minimum_deposit', trans("admin/broker.minimum_deposit"), array('class' => 'control-label')) !!}
            <div class="controls">
                {!! Form::text('minimum_deposit', null, array('class' => 'form-control')) !!}
                <span class="help-block">{{ $errors->first('minimum_deposit', ':message') }}</span>
            </div>
        </div>
              <div class="form-group  {{ $errors->has('maximal_leverage') ? 'has-error' : '' }}">
            {!! Form::label('maximal_leverage', trans("admin/broker.maximal_leverage"), array('class' => 'control-label')) !!}
            <div class="controls">
                {!! Form::text('maximal_leverage', null, array('class' => 'form-control')) !!}
                <span class="help-block">{{ $errors->first('maximal_leverage', ':message') }}</span>
            </div>
        </div>
              <div class="form-group  {{ $errors->has('minimum_lot_size') ? 'has-error' : '' }}">
            {!! Form::label('minimum_lot_size', trans("admin/broker.minimum_lot_size"), array('class' => 'control-label')) !!}
            <div class="controls">
                {!! Form::text('minimum_lot_size', null, array('class' => 'form-control')) !!}
                <span class="help-block">{{ $errors->first('minimum_lot_size', ':message') }}</span>
            </div>
        </div>
              <div class="form-group  {{ $errors->has('maximum_lot_size') ? 'has-error' : '' }}">
            {!! Form::label('maximum_lot_size', trans("admin/broker.maximum_lot_size"), array('class' => 'control-label')) !!}
            <div class="controls">
                {!! Form::text('maximum_lot_size', null, array('class' => 'form-control')) !!}
                <span class="help-block">{{ $errors->first('maximum_lot_size', ':message') }}</span>
            </div>
        </div>
              <div class="form-group  {{ $errors->has('commission') ? 'has-error' : '' }}">
            {!! Form::label('commission', trans("admin/broker.commission"), array('class' => 'control-label')) !!}
            <div class="controls">
                {!! Form::text('commission', null, array('class' => 'form-control')) !!}
                <span class="help-block">{{ $errors->first('commission', ':message') }}</span>
            </div>
        </div>
              <div class="form-group  {{ $errors->has('spread') ? 'has-error' : '' }}">
            {!! Form::label('spread', trans("admin/broker.spread"), array('class' => 'control-label')) !!}
            <div class="controls">
                {!! Form::text('spread', null, array('class' => 'form-control')) !!}
                <span class="help-block">{{ $errors->first('spread', ':message') }}</span>
            </div>
        </div>
              <div class="form-group  {{ $errors->has('decimals') ? 'has-error' : '' }}">
            {!! Form::label('decimals', trans("admin/broker.decimals"), array('class' => 'control-label')) !!}
            <div class="controls">
                {!! Form::text('decimals', null, array('class' => 'form-control')) !!}
                <span class="help-block">{{ $errors->first('decimals', ':message') }}</span>
            </div>
        </div>
              <div class="form-group  {{ $errors->has('scalping_allowed') ? 'has-error' : '' }}">
            {!! Form::label('scalping_allowed', trans("admin/broker.scalping_allowed"), array('class' => 'control-label')) !!}
            <div class="controls">
                {!! Form::text('scalping_allowed', null, array('class' => 'form-control')) !!}
                <span class="help-block">{{ $errors->first('scalping_allowed', ':message') }}</span>
            </div>
        </div>
        
    </div>
     <!-- ./ accounts tab -->
    <div class="tab-pane" id="tab-description">
        
          <div class="form-group  {{ $errors->has('description') ? 'has-error' : '' }}">
            {!! Form::label('description', trans("admin/article.description"), array('class' => 'control-label')) !!}
            <div class="controls">
                {!! Form::textarea('description', null, array('class' => 'form-control')) !!}
                <span class="help-block">{{ $errors->first('description', ':message') }}</span>
            </div>
        </div>
        
    </div>
    <!-- ./ tabs content -->
</div>
        
<!-- Form Actions -->

<div class="form-group">
    <div class="col-md-12">
        <button type="reset" class="btn btn-sm btn-warning close_popup">
            <span class="glyphicon glyphicon-ban-circle"></span> {{
						trans("admin/modal.cancel") }}
        </button>
        <button type="reset" class="btn btn-sm btn-default">
            <span class="glyphicon glyphicon-remove-circle"></span> {{
						trans("admin/modal.reset") }}
        </button>
        <button type="submit" class="btn btn-sm btn-success">
            <span class="glyphicon glyphicon-ok-circle"></span>
            @if	(isset($broker))
                {{ trans("admin/modal.edit") }}
            @else
                {{trans("admin/modal.create") }}
            @endif
        </button>
    </div>
</div>
<!-- ./ form actions -->

</form>
@stop
