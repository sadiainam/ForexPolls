@extends('layouts.app')
@section('title') About :: @parent @stop
@section('content')
<div class="container-fluid">
 <div class="col-md-10">
    <div class="panel panel-default">
        <div class="panel-heading">{{$broker->broker_name}}</div>
        <div class="panel-body">

            <div class="col-md-4">
                <img src="http://placehold.it/270x100">
                <p>www.abc.com</p>
                <div>Overall Score: 3.6 / 5</div>

                <div>Total Votes: 312</div>


            </div>
            <div class="col-md-8">
                <div class="col-md-6">

                    <div class="row">



                        {!!Form::open()!!}
                        <label>Platform</label>
                        <input id="input-id" name="input-platform" type="number" class="rating" min=1 max=5 step="1" data-size="xs">
                        <input id="input-two" name="input-pricing" type="number" class="rating" min=1 max=5 step="1" data-size="xs">
                        <input id="input-three" name="input-customer_service" type="number" class="rating" min=1 max=5 step="1" data-size="xs">
                        <input id="input-four" name="input-feature" type="number" class="rating" min=1 max=5 step="1" data-size="xs">
                        <input id="input-five" name="input-name" type="number" class="rating" min=1 max=5 step="1" data-size="xs">
                        <input type="hidden" value="{{ $broker->id}}" name="broker_id" id="broker_id">
                        <button id="button_rating">Rate</button>
                    </div>
                </div>


                <div class="col-md-6">
                    <div class="container">
                        <div class="row">
                            <div class="col-md-12">
                                <!--<div class="panel panel-default">-->
                                <!--<div class="panel-heading">Dashboard</div>-->
                                <!--<div class="panel-body">-->
                                <div id="container"></div>
                            </div>
                        </div>
                        <!--                    </div>
                                            </div>-->
                    </div>
                </div>





            </div>






        </div>


    </div>
    <div class="panel panel-default">
        <div class="panel-heading">
            <span class="panel-title pull-left">
                Reviews
            </span>

            <button class="btn btn-default pull-right" data-toggle="modal" data-target="#myModal">New</button>
            <div class="clearfix"></div>
        </div>
        <div class="panel-body">
            @foreach ($comments as $comment)
            <p><h3>{{ $comment->name}}<small>       {{ $comment->created_at->format('M d Y') }}   at  {{$comment->created_at->format('h:i')}}</small></h3></p>
            <p> {{ $comment->review}}</p>
            <hr>
            @endforeach          

        </div>
    </div>
    </div>
 <div class="col-md-2">
	<div id="sidebar">
				
<!--	  	<ul>
		    <li><a href="index.html">Add</a></li>
		    <li><a href="css.html">ADD</a></li>
		    <li><a href="reveal.html">ADD</a></li>
		</ul>-->
 <img src="http://placehold.it/100x400">
	
	</div>
	</div>
</body>

<!-- Modal -->
<div id="myModal" class="modal fade" role="dialog">
    <div class="modal-dialog">

        Submit Your Reviews
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title">Submit Your Reviews
                </h4>
            </div>
            <div class="modal-body">
                {!!Form::open()!!}
                <div class="form-group">
                    <label for="name">Name:</label>
                    <input type="text" class="form-control" id="name">
                    <small>Required</small>
                </div>
                <div class="form-group">
                    <div class="form-group">
                        <label for="email">Email address:</label>
                        <input type="email" class="form-control" id="email">
                        <small>Required (will not be published)</small>
                    </div>
                </div>
                <div class="form-group">
                    <div class="form-group">
                        <label for="account">Account Number:</label>
                        <input type="text" class="form-control" id="account">
                        <small>Only first and last digit will be published</small>
                    </div>
                </div>    
                <div class="form-group">
                    <label for="account">Impression About Company:</label>
                    <select id="impression">
                        <option value="positive">Positive</option>
                        <option value="negative">Negative</option>
                        <option value="neutral">Neutral</option>
                    </select>
                </div>
                <div class="form-group">
                    <div class="form-group">
                        <label for="account">Select Country:</label>
                        <select id="country">
                            <option value="usa">USA</option>
                            <option value="uae">UAE</option>
                            <option value="uk">UK</option>
                        </select>
                    </div>
                </div>
                <div class="form-group">
                    <label for="review">Review:</label>
                    <textarea class="form-control" rows="5" id="review"></textarea>
                </div>
                <input type="hidden" value="{{ $broker->id}}" id="broker_comment_id">
            </div>
            <div class="modal-footer">
                <button type="submit" class="btn btn-default" id="button_review" data-dismiss="modal">Submit</button>    

            </div>
        </div>

    </div>

</div>




</html>
<script src="https://code.highcharts.com/highcharts.js"></script>
<script type="text/javascript">
$(function () {
    var data_platform = <?php echo $platform; ?>;
    var data_pricing = <?php echo $pricing; ?>;
    var data_customer_service = <?php echo $customer_service; ?>;
    var data_feature = <?php echo $feature; ?>;
    //   alert(date_feature);
    $('#container').highcharts({
        chart: {
            type: 'column',
            height: 220,
            width: 250,
        },
        title: {
            text: '',
            x: -20
        },
        credits: {
            enabled: false
        },
        xAxis: {
            categories: []
        },
        yAxis: {
            title: {
                text: ''
            },
            tickInterval: 1,
            min: 0,
            max: 5,
        },
        series: [{
                name: 'Platform',
                data: data_platform
            }, {
                name: 'Pricing',
                data: data_pricing
            },
            {
                name: 'Customer Service',
                data: data_customer_service
            },
            {
                name: 'Features',
                data: data_feature
            }]





    });
});

$(function() {

    var offset = $("#sidebar").offset();
    var topPadding = 15;

    $(window).scroll(function() {
    
        if ($(window).scrollTop() > offset.top) {
        
            $("#sidebar").stop().animate({
            
                marginTop: $(window).scrollTop() - offset.top + topPadding
            
            });
        
        } else {
        
            $("#sidebar").stop().animate({
            
                marginTop: 0
            
            });
        
        }
        
            
    });

});
</script>
<style type="text/css">
	
/*    	* { margin: 0; padding: 0; }
        body { font: 14px/1.4 Georgia, serif; }
        #page-wrap { width: 600px; margin: 15px auto; position: relative; }
        p { margin: 0 0 15px 0; }
        p:first-child { background: #fffcde; padding: 10px; }
        #sidebar ul { background: #eee; padding: 10px; }
        li { margin: 0 0 0 20px; }
        #main { width: 390px; float: left; }
        #sidebar { width: 190px; position: fixed; left: 50%; top: 90px; margin: 0 0 0 110px; }*/

    </style>
    
    <!--[if IE 6]>
	   <style type="text/css">
	       html, body { height: 100%; overflow: auto; }
	       #sidebar { position: absolute; }
	       #page-wrap { margin-top: -5px; }
	       #ie6-wrap { position: relative; height: 100%; overflow: auto; width: 100%; }
	   </style>
    <![endif]-->
    
    <!--[if IE 7]>
	   <style type="text/css">
	       #sidebar { margin-top: -10px;  }
	       #page-wrap { margin-top: -5px; }
	   </style>
    <![endif]-->

@stop

