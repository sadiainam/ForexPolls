@extends('layouts.app')
@section('title') About :: @parent @stop
@section('content')


<div class="container-fluid">
    <div class="row">
        <div class="col-md-4">


            <div class="panel panel-default">

                <div class="panel-heading">This Page is Disabled</div>

                <div class="panel-body">This page is temporarily disabled by the site administrator for some reason.<br> <a href="#">Click here</a> to enable the page.</div>

            </div>


        </div>
        <div class="col-md-4">


            <div class="panel panel-default">

                <div class="panel-heading">This Page is Disabled</div>

                <div class="panel-body">This page is temporarily disabled by the site administrator for some reason.<br> <a href="#">Click here</a> to enable the page.</div>

            </div>


        </div>
        <div class="col-md-4">
            <div class="panel panel-default" id="new_comparision">
                <!-- Default panel contents -->
                <div class="panel-heading">Add A Broker</div>
                

                <!-- List group -->
                <ul id="add_comparision" class="list-group">
                    @foreach ($brokers_list as $broker)
                    <a href="#" > <li id ="{{$broker->id }}" class="list-group-item"><span class="glyphicon glyphicon-plus" aria-hidden="true"></span> {{$broker->broker_name}}</li><a>
                    @endforeach 
                    <input type="hidden" name="_token" value="{{ csrf_token() }}">
                </ul>
            </div>
           


        </div>
    </div>
</div>


</body>

</html>



<script type="text/javascript">


    $('#add').click(function () {
        $(this).before('<div class="panel panel-default"><div class="panel-heading">This Page is Disabled</div><div class="panel-body">This page is temporarily disabled by the site administrator for some reason.<br> <a href="#">Click here</a> to enable the page.</div><span class="remove">Remove Option</span></div>');
    });

    $(document).on('click', '.remove', function () {
        $(this).parent('div').remove();
    });
</script>
<style>
    .block {
        display: block;
    }
    input {
        width: 50%;
        display: inline-block;
    }
    span {
        display: inline-block;
        cursor: pointer;
        text-decoration: underline;
    }
</style>
@stop