@extends('layouts.app')
@section('title') About :: @parent @stop
@section('content')
 
                
    <div class="container-fluid">
   
        <div class="row">
  <!--<div class="col-xs-6 col-md-2"><img src="http://placehold.it/150x650"></div>-->
  <div class="col-xs-6 col-md-8">   <h3>Brokers</h3>
                 
               
                    
      <table id="example" class="display" cellspacing="0" width="100%">
    <thead>
      <tr>
        <th>Name</th>
        <th>Vote</th>
        <th>Post</th>
        <th>Score</th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <td><a href="/1">FX Choice</td>
        <td>23</td>
        <td>23</td>
        <td><a href="#"><div class="progress">
  <div class="progress-bar progress-bar-success" role="progressbar" aria-valuenow="40"
  aria-valuemin="0" aria-valuemax="100" style="width:40%">
    40% Complete (success)
  </div>
</div></td>
      </tr>
           <tr>
        <td>FX Choice</td>
        <td>23</td>
        <td>23</td>
        <td><div class="progress">
  <div class="progress-bar progress-bar-success" role="progressbar" aria-valuenow="40"
  aria-valuemin="0" aria-valuemax="100" style="width:40%">
    40% Complete (success)
  </div>
</div></td>
      </tr>
           <tr>
        <td>FX Choice</td>
        <td>23</td>
        <td>23</td>
        <td><div class="progress">
  <div class="progress-bar progress-bar-success" role="progressbar" aria-valuenow="40"
  aria-valuemin="0" aria-valuemax="100" style="width:40%">
    40% Complete (success)
  </div>
</div></td>
      </tr>
           <tr>
        <td>FX Choice</td>
        <td>23</td>
        <td>23</td>
        <td><div class="progress">
  <div class="progress-bar progress-bar-success" role="progressbar" aria-valuenow="40"
  aria-valuemin="0" aria-valuemax="100" style="width:40%">
    40% Complete (success)
  </div>
</div></td>
      </tr>
           <tr>
        <td>FX Choice</td>
        <td>23</td>
        <td>23</td>
        <td><div class="progress">
  <div class="progress-bar progress-bar-danger" role="progressbar" aria-valuenow="70"
  aria-valuemin="0" aria-valuemax="100" style="width:10%">
    10% Complete (danger)
  </div>
</div></td>
      </tr>
      
    </tbody>
  </table>
  </div>
  <div class="col-xs-6 col-md-4"><img src="http://placehold.it/250x650"></div>
</div>
        </div>
  

    
                 
</body>

</html>

@stop
