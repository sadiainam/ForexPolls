<!DOCTYPE html>
<html lang="en">

<head>
<meta charset="utf-8" />
<title>AmazingBiz | Free HTML5 Responsive Template</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="description" content="">
<meta name="author" content="">
<!-- Stylesheets -->
<link href="{{ URL::asset('css/template_css/prettyPhoto.css') }}" rel="stylesheet" type="text/css" />
<link href="{{ URL::asset('css/template_css/camera.css') }}" rel="stylesheet" type="text/css" id="camera-css" media="all" />
<link href="{{ URL::asset('css/template_css/bootstrap.css') }}" rel="stylesheet" type="text/css" />
<link href="{{ URL::asset('css/template_css/site.css') }}" rel="stylesheet" type="text/css" />
<link href="{{ URL::asset('css/template_css/bootstrap-responsive.css') }}" rel="stylesheet" type="text/css" />
<!--<link rel="stylesheet" id="camera-css"  href="template_css/.css" type="text/css" media="all">
<link href="template_css/bootstrap.css" rel="stylesheet">
<link href="template_css/site.css" rel="stylesheet">
<link href="template_css/bootstrap-responsive.css" rel="stylesheet">-->

<!-- Font -->
<link href='http://fonts.googleapis.com/css?family=Muli' rel='stylesheet' type='text/css'>



<!--[if lt IE 9]>
	<script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
<![endif]-->

</head>
<body >
	<div class="container box_shadow">
		
		<!--header-->
		<div class="header">
			<div class="wrap">				
				<div class="container">
					<div class="fleft logo"><a href="index.html"><img src="{{ asset('img/template_images/logo.png') }}" alt="Amazing Ideas" /></a></div>
					<div class="navbar fright">
					<nav id="main_menu">
							<div class="menu_wrap">
								<ul class="nav sf-menu">
									<li class="current first"><a href="index-2.html">Home</a></li>
									<li class="last"><a href="about.html">About</a></li>
									<li class="sub-menu first"><a href="javascript:{}">Services</a>
										<ul>
											<li><a href="internet.html"><span>-</span>Internet Strategy</a></li>
											<li><a href="mobile.html"><span>-</span>Mobile Marketing</a></li>
											<li><a href="social.html"><span>-</span>Social Media</a></li>
											<li><a href="analytics.html"><span>-</span>Analytics</a></li>
										</ul>
									</li>
                                    
                                    <li class="sub-menu first"><a href="javascript:{}">Features</a>
										<ul>
											<li><a href="scaffolding.html"><span>-</span>Scaffolding</a></li>
											<li><a href="typography.html"><span>-</span>Typography</a></li>
											<li><a href="shortcodes.html"><span>-</span>Shortcodes</a></li>
											<li><a href="tables.html"><span>-</span>Tables</a></li>
										</ul>
									</li>
                                    
									<li class="sub-menu last"><a href="javascript:{}">Portfolio</a>
										<ul>
											<li><a href="portfolio_2columns.html"><span>-</span>2 Columns</a></li>
											<li><a href="portfolio_3columns.html"><span>-</span>3 Columns</a></li>
											<li><a href="portfolio_4columns.html"><span>-</span>4 Columns</a></li>
										</ul>
									</li>
									<li class="sub-menu first"><a href="javascript:{}">Blog</a>
										<ul>
											<li><a href="blog.html"><span>-</span>Blog with right sidebar</a></li>
											<li><a href="blog_post.html"><span>-</span>Blog post</a></li>
										</ul>
									</li>
									<li class="last"><a href="contacts.html">Contact</a></li>
								</ul>
							</div>
						</nav>
				</div>
					<div class="clear"></div>
				</div>
				
			</div>
		</div>
        <!--//header-->
        
        
		
		 
		<!--page_container-->
		<div class="page_container">
			<div class="container">
				<!--slider-->
				<div id="main_slider">
					<div class="camera_wrap" id="camera_wrap_1">
						<div data-src="images/slider/slide1.jpg">
							<div class="camera_caption fadeIn">
								<div class="slide_descr">Manage and Measure <br/>Your Marketing Goals</div>
							</div>
						</div>
						<div data-src="images/slider/slide2.jpg">
							<div class="camera_caption fadeIn">
								<div class="slide_descr">Expertise You Can Count On<br/>Results You Can Measure</div>
							</div>
						</div>
						<div data-src="images/slider/slide3.jpg">
							<div class="camera_caption2 fadeIn">
								<div class="slide_descr">Your Lead-Generation Partner<br/>With a Vision</div>
							</div>
						</div>
					</div><!-- #camera_wrap_1 -->
					<div class="clear"></div>	
				</div>
				<!--//slider-->
			</div>
			
			<!--planning-->
			<div class="wrap planning">
				<div class="fist_line_planning">
					<a href="javascript:void(0);">
						<span class="color1 service_block">
							<img class="icon_block" src="{{ asset('img/template_images/icon1.png') }}" />
                            <span class="link_title">Internet Strategy</span>
							<span class="service_txt">Our Strategy Team converts brand values into actionable brand behavior. We implement and measure e-business strategies to provide maximum exposure to consumers everywhere around the globe. Our strategy makes our clients thrive. </span>
						</span>
					</a>
					<a href="javascript:void(0);">
						<span class="color2 service_block">
							<img class="icon_block" src="{{ asset('img/template_images/icon2.png') }}" />
							<span class="link_title">Mobile Marketing</span>
							<span class="service_txt"> With mobile search, your ads will display through search results performed on cell phones in order to expand your reach. By allowing your ads to travel wherever your customers go, the potential to promote your business is available anytime, anywhere.</span>
						</span>
					</a>
					<a href="javascript:void(0);">
						<span class="color3 service_block">
							<img class="icon_block" src="{{ asset('img/template_images/icon3.png') }}" />
							<span class="link_title">Social Media</span>
							<span class="service_txt"> Being a social media marketing agency, we have developed a digital strategy to maximize your organization's engagement and benefit from this exciting and powerful communication platform, while complementing other digital marketing initiatives.</span>
						</span>
					</a>
					<a href="javascript:void(0);">
						<span class="color4 service_block">
							<img class="icon_block" src="{{ asset('img/template_images/icon4.png') }}" />
							<span class="link_title">Analystics</span>
							<span class="service_txt">A major benefit of online and digital media is the ability to track audience response in real-time.. We have a best in class team that vigorously gathers data that we harness to improve the quality and results of our clients' internet marketing campaigns.</span>
						</span>
					</a>
					<div class="clear"></div>
				</div>
			</div>
			<!--//planning-->
			
			<!--Recent Gallery-->
			<div class="wrap recent_gal_block">
				<div class="container">
					<h2 class="title">Featured Campaigns</h2>
					<ul class="row">
						<li class="span4">
							<div class="proj_block">
								<img src="{{ asset('img/template_images/featured_works/1.jpg') }}" alt="" />
								<a href="template_images/featured_works/1.jpg" rel="prettyPhoto[portfolio1]"><span class="portfolio_zoom1"></span></a>
							</div>
						</li>
						<li class="span4">
							<div class="proj_block">
								<img src="{{ asset('img/template_images/featured_works/2.jpg') }}" alt="" />
								<a href="template_images/featured_works/2.jpg" rel="prettyPhoto[portfolio1]"><span class="portfolio_zoom1"></span></a>
							</div>
						</li>
						<li class="span4">
							<div class="proj_block">
								<img src="{{ asset('img/template_images/featured_works/3.jpg') }}" alt="" />
								<a href="template_images/featured_works/3.jpg" rel="prettyPhoto[portfolio1]"><span class="portfolio_zoom1"></span></a>
							</div>
						</li>
						<div class="clear"></div>
					</ul>
				</div>
			</div>
			<!--//Recent Gallery-->
			
			<!--Welcome-->
			<div class="wrap welcome_bg">
				<div class="container">
					<div class="welcome_block">
						<p class="fleft">Our Team of Specialists Drive Business Results</p>
						<a class="fright" href="javascript:void(0);">Learn More</a>
						<div class="clear"></div>
					</div>
				</div>
			</div>
			<!--//Welcome-->
			
			<!--Latest news-->
			<div class="wrap">
				<h2 class="title">Success Stories</h2>
				<ul class="row">
					<li class="span3 post_prev">
						<a class="post_img" href="javascript:void(0);"><img src="{{ asset('img/template_images/blog/post_prev1.jpg') }}" /></a>
						<a class="title" href="javascript:void(0);">Food for child</a>
						<p class="post_prev_date">24 August, 2020</p>
						20% improvement in outreach campaigns in Q1/2013
					</li>
					<li class="span3 post_prev">
						<a class="post_img" href="javascript:void(0);"><img src="{{ asset('img/template_images/blog/post_prev2.jpg') }}" /></a>
						<a class="title" href="javascript:void(0);">Child`s safety</a>
						<p class="post_prev_date">24 August, 2020</p>
						20% more induction + 25% improvement in new registrations 
					</li>
					<li class="span3 post_prev">
						<a class="post_img" href="javascript:void(0);"><img src="{{ asset('img/template_images/blog/post_prev3.jpg') }}" /></a>
						<a class="title" href="javascript:void(0);">Sport & lifestyle</a>
						<p class="post_prev_date">24 August, 2020</p>
						12000 new subscribers and 28000 new facebook fans in 6 months
					</li>
					<li class="span3 post_prev">
						<a class="post_img" href="javascript:void(0);"><img src="{{ asset('img/template_images/blog/post_prev4.jpg') }}" /></a>
						<a class="title" href="javascript:void(0);">psychologic tips </a>
						<p class="post_prev_date">24 August, 2020</p>
						Successful launch of digital magazine
					</li>
					<div class="clear"></div>
				</ul>
			</div>
			<!--Latest news-->
		</div>		
		
		<!--//page_container-->
		
		<!--footer-->
		<div id="footer">
			<div class="wrap">
				<div>
					<div class="row">
						<div class="span4">
							<h2 class="title">What is AmazingBiz?</h2>
							<p>We are a digial marketing agency specialising in Google AdWord and Bing Ads.
As a search marketing agency, we guide your digital marketing campaign management to new levels of performance. </p>
<p>AmazingBiz has improved digital marketing performance for hundreds of clients over the past 10 years. </p>
						</div>
						<div class="span3">
							<h2 class="title">Popaular Searches</h2>
							<div class="tags">
								<a href="javascript:void(0);">Marketing</a>
								<a href="javascript:void(0);">Campaign Management</a>
								<a href="javascript:void(0);">Social Media</a>
								<a href="javascript:void(0);">Agency</a>
								<a href="javascript:void(0);">Creative</a>
								<a href="javascript:void(0);">Free Template</a>
								<a href="javascript:void(0);">Free Website</a>
                                <a href="javascript:void(0);">CSS3</a>
								<a href="javascript:void(0);">Website Template</a>
								<a href="javascript:void(0);">HTML5</a>
								<a href="javascript:void(0);">EGrappler.com</a>
								<a href="javascript:void(0);">jQuery</a>
							</div>
						</div>
						<div class="span5">
							<h2 class="title">Get in touch!</h2>
							<form action="#" method="post" id="contact_form">
								<input type="text" name="name" id="name" value="Name" onFocus="if (this.value == 'Name') this.value = '';" onBlur="if (this.value == '') this.value = 'Name';" />
								<input type="text" name="email" id="email" value="Email" onFocus="if (this.value == 'Email') this.value = '';" onBlur="if (this.value == '') this.value = 'Email';" />
								<textarea name="message" id="message" onFocus="if (this.value == 'Message') this.value = '';" onBlur="if (this.value == '') this.value = 'Message';" >Message</textarea>
								<div class="clear"></div>
								<input type="submit" class="contact_btn" id="button-send" value="Send" />
								<div class="clear"></div>
							</form>
						</div>
					</div>
				</div>
			</div>
			
			<div class="footer_bottom">
				<div class="wrap">
					<div class="container">
						<div class="fleft copyright">AmazingBiz &copy; 2014  |  <a href="javascript:void(0);">Privacy Policy</a></div>
						<div class="fright follow_us">
							<ul>
								<li><a href="http://twitter.com/egrappler" class="soc1"></a></li>					
								<li><a href="http://facebook.com/egrappler" class="soc2"></a></li>
								<li><a href="#" class="soc3"></a></li>
								<div class="clear"></div>
							</ul>
						</div>
						<div class="clear"></div>
					</div>
				</div>
			</div>
		</div>
		<!--//footer-->
	</div>

	<!--<script src="jquery.min.js"></script>-->
        <script type="text/javascript" src="{{ URL::asset('js/template_js/jquery.min.js') }}"></script>
        <script type="text/javascript" src="{{ URL::asset('js/template_js/jquery.easing.1.3.js') }}"></script>
        <script type="text/javascript" src="{{ URL::asset('js/template_js/jquery.mobile.customized.min.js') }}"></script>
        <script type="text/javascript" src="{{ URL::asset('js/template_js/camera.js') }}"></script>
        <script type="text/javascript" src="{{ URL::asset('js/template_js/bootstrap.js') }}"></script>
        <script type="text/javascript" src="{{ URL::asset('js/template_js/jquery.prettyPhoto.js') }}"></script>
        <script type="text/javascript" src="{{ URL::asset('js/template_js/htweet.js') }}"></script>
        <script type="text/javascript" src="{{ URL::asset('js/template_js/custom.js') }}"></script>
<!--       <script type="text/javascript" src="template_js/jquery.easing.1.3.js"></script>
    <script type="text/javascript" src="template_js/jquery.mobile.customized.min.js"></script>
    <script type="text/javascript" src="template_js/camera.js"></script>
    <script src="template_js/bootstrap.js"></script>
    <script src="template_js/superfish.js"></script>
    <script type="text/javascript" src="template_js/jquery.prettyPhoto.js"></script>
    <script src="template_js/htweet.js" type="text/javascript"></script>
    <script type="text/javascript" src="template_js/custom.js"></script>
	-->
</body>

</html>

