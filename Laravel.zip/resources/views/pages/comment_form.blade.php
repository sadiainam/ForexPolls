<!--@extends('layouts.app')-->
@section('title') About :: @parent @stop
@section('popup')
<div id="myModal" class="modal fade" role="dialog">
<div class="container-fluid">

    <div class="panel panel-default">
        <div class="panel-heading">Title</div>
        <div class="panel-body">


            <div class="col-md-8">

                <div class="row">


                    {!!Form::open()!!}
                    <div class="form-group">
                        <label for="name">Name:</label>
                        <input type="text" class="form-control" id="name">
                        <small>Required</small>
                    </div>
                    <div class="form-group">
                        <div class="form-group">
                            <label for="email">Email address:</label>
                            <input type="email" class="form-control" id="email">
                            <small>Required (will not be published)</small>
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="form-group">
                            <label for="account">Account Number:</label>
                            <input type="text" class="form-control" id="account">
                            <small>Only first and last digit will be published</small>
                        </div>
                    </div>    
                    <!--                    <div class="dropdown">
                                            <button class="btn btn-primary dropdown-toggle" type="button" id="impression" data-toggle="dropdown">Impression About Company
                                                <span class="caret"></span></button>
                                            <ul class="dropdown-menu">
                                                <li><a href="#">Positive</a></li>
                                                <li><a href="#">Negative</a></li>
                                                <li><a href="#">Neutral</a></li>
                                            </ul>
                    
                                        </div>-->
                    <!--<div class="dropdown">Impression About Company-->
                     <div class="form-group">
                        <div class="form-group">
                            <label for="account">Impression About Company:</label>
                        <select id="impression">
                            <option value="positive">Positive</option>
                            <option value="negative">Negative</option>
                            <option value="neutral">Neutral</option>
                        </select>
                    </div>
                    </div>
                    <div class="form-group">
                        <div class="form-group">
                            <label for="account">Select Country:</label>
                        <select id="country">
                            <option value="usa">USA</option>
                            <option value="uae">UAE</option>
                            <option value="uk">UK</option>
                        </select>
                    </div>
                    </div>
                    <div class="form-group">
                        <label for="review">Review:</label>
                        <textarea class="form-control" rows="5" id="review"></textarea>
                    </div>
                    <button type="submit" class="btn btn-default" id="button_review">Submit</button>    
                </div>






            </div>






        </div>


    </div>
    </div>

</body>

</html>

@stop

