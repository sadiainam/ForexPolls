<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>@section('title') Laravel 5 Sample Site @show</title>
        @section('meta_keywords')
        <meta name="keywords" content="your, awesome, keywords, here"/>
        @show @section('meta_author')
        <meta name="author" content="Jon Doe"/>
        @show @section('meta_description')
        <meta name="description"
              content="Lorem ipsum dolor sit amet, nihil fabulas et sea, nam posse menandri scripserit no, mei."/>
        @show

        <link href="{{ asset('css/site.css') }}" rel="stylesheet">
        <!--<link href="{{ URL::asset('css/template_css/prettyPhoto.css') }}" rel="stylesheet" type="text/css" />-->
        <link href="{{ URL::asset('css/template_css/camera.css') }}" rel="stylesheet" type="text/css" id="camera-css" media="all" />
        <!--<link href="{{ URL::asset('css/template_css/bootstrap.css') }}" rel="stylesheet" type="text/css" />-->
        <!--<link href="{{ URL::asset('css/template_css/site.css') }}" rel="stylesheet" type="text/css" />-->
        <!--<link href="{{ URL::asset('css/template_css/bootstrap-responsive.css') }}" rel="stylesheet" type="text/css" />-->
        <link href="https://cdn.datatables.net/1.10.12/css/jquery.dataTables.min.css" rel="stylesheet" type="text/css" />
        <link href="http://netdna.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.css" rel="stylesheet">
        <link href="{{ URL::asset('css/star-rating.css') }}" media="all" rel="stylesheet" type="text/css" />

        <script src="{{ asset('js/site.js') }}"></script>
        <script type="text/javascript" src="{{ URL::asset('js/template_js/jquery.min.js') }}"></script>
        <script type="text/javascript" src="{{ URL::asset('js/template_js/bootstrap.js') }}"></script>
        <script type="text/javascript" src="{{ URL::asset('js/template_js/jquery.easing.1.3.js') }}"></script>
        <script type="text/javascript" src="{{ URL::asset('js/template_js/jquery.mobile.customized.min.js') }}"></script>
        <script type="text/javascript" src="{{ URL::asset('js/template_js/jquery.prettyPhoto.js') }}"></script>
        <script type="text/javascript" src="{{ URL::asset('js/template_js/htweet.js') }}"></script>
        <script type="text/javascript" src="{{ URL::asset('js/template_js/custom.js') }}"></script>
        <script type="text/javascript" src="{{ URL::asset('js/template_js/camera.js') }}"></script>
        <!--<script type="text/javascript" src="//code.jquery.com/jquery-1.12.3.js"></script>old version-->
        <script type="text/javascript" src="https://cdn.datatables.net/1.10.12/js/jquery.dataTables.min.js"></script>
        <script type="text/javascript" src="//ajax.googleapis.com/ajax/libs/jquery/2.1.0/jquery.js"></script>
        <script src="{{ URL::asset('js/star-rating.js') }}" type="text/javascript"></script>

        <script>
$(document).ready(function () {
    //$('#example').DataTable();



});
        </script>

        @yield('styles')
        <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
        <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
        <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
        <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
        <![endif]-->

        <link rel="shortcut icon" href="{!! asset('assets/site/ico/favicon.ico')  !!} ">
    </head>
    <body>
        @include('partials.nav')

        <div class="container">
            @yield('content')
        </div>
        @include('partials.footer')

        <!-- Scripts -->
        <script type="text/javascript">
            // initialize with defaults
            $("#input-id").rating({min: 1, max: 5, size: 'xs'});



            $("#button_rating").click(function () {
//                alert('here');
                var rate1 = $('#input-id').val();
                var rate2 = $('#input-two').val();
                var rate3 = $('#input-three').val();
                var rate4 = $('#input-four').val();
                var rate5 = $('#input-five').val();
                var broker_id = $('#broker_id').val();

                $.ajax({
                    url: '{{url("pages/brokers")}}' + '/' + broker_id,
                    type: "post",
                    data: {'rate1': rate1,
                        'rate2': rate2,
                        'rate3': rate3,
                        'rate4': rate4,
                        'rate5': rate5,
                        'broker_id': broker_id,
                        '_token': $('input[name=_token]').val()},
                    success: function (data) {

                        alert('rating done successfully')
                    }

                });
            });

            $("#button_review").click(function () {
//            e.preventDefault(); 
                var name = $('#name').val();
                var email = $('#email').val();
                var account = $('#account').val();
                var impression = $("#impression option:selected").val()
                var country = $("#country option:selected").val()
                var review = $('#review').val();
                var broker_id = $('#broker_comment_id').val();

                $.ajax({
                    url: '{{url("comment/add")}}' + '/' + broker_id,
                    type: "post",
                    data: {'name': name,
                        'email': email,
                        'account': account,
                        'impression': impression,
                        'country': country,
                        'review': review,
                        'id': 1,
                        'broker_id': broker_id,
                        '_token': $('input[name=_token]').val()},
                    success: function (data) {

                        alert('comment done successfully')
                    }

                });
            });


            $("#add_comparision li").click(function () {
                var broker_id = this.id;
//        alert(broker_id);

                $.ajax({
                    url: '{{url("return_comparision_data")}}' + '/' + broker_id,
                    type: "post",
                    dataType: "json",
                    data: {'broker_id': broker_id,
                        '_token': $('input[name=_token]').val()},
                    
                    success: function (data) {
//                        alert(data['broker_name']);
//                        alert('comment done successfully')
$('#new_comparision').html(data['broker_name']);
                    }

                });



            });

        </script>
        @yield('scripts')

    </body>
</html>
