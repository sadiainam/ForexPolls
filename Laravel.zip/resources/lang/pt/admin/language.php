<?php

return [
    'code' => 'Código',
    'icon' => 'Ícone',
    'languages' => 'Idiomas',

];