<?php

return [
    'news' 			=> 'Notícias',
    'introduction' 	=> 'Introdução',
    'content' 		=> 'Conteúdo',
    'source' 		=> 'Fonte',
    'picture' 		=> 'Imagem',
    'category' 		=> 'Categoria',

];