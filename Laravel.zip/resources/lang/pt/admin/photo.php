<?php

return [
    'photo' 		=> 'Foto',
    'album' 		=> 'Álbum',
    'album_cover' 	=> 'Capa',
    'slider'		=> 'Slider',
    'description' 	=> 'Descrição',
    'picture' 		=> 'Imagem',
];