<?php

return [
    'newscategories' => 'Categoria de Notícias',


];