<?php

return [
    'users'                 => 'Usuários',
    'name'                  => 'Nome',
    'username'              => 'Nome de usuário',
    'email'                 => 'E-mail',
    'password'              => 'Senha',
    'password_confirmation' => 'Confirmação da senha',
    'activate_user'         => 'Ativo',
    'active_user'           => 'Usuário ativo',
    'yes'                   => 'Sim',
    'no'                    => 'Não',
    'roles'                 => 'Papéis',
    'roles_info'            => 'Adicionando este papel ao usuário, será adicionado todos os privilégios deste papel ao usuário.'

];
