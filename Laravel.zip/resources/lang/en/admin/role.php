<?php

return [
    'roles' => 'Roles',
    'adminrole' => 'Admin roles',
    'userrole'  =>  'User roles',
    'choose_role' =>   'Choose permissions',
    'name'  => 'Name',

];