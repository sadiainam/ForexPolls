<?php

return [
    'photo' => 'Photos',
    'album' =>  'Album',
    'album_cover' => 'Album cover',
    'slider' => 'Slider',
    'description' => 'Description',
    'picture' => 'Picture',

];