<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

return [
    'broker' => 'Broker',
    'brokers' => 'Brokers',
    'country' => 'Country',
    'number_of_employees' => 'No. of Employees',
    'broker_name' => 'Broker Name',
    'broker_type' => 'Broker Type',
    'operating_year' => 'Operating Year',
    'no_of_employees' => 'No. of Employees',
    'international_offices' => 'International Offices',
    'regulation' => 'Regulation',
    'address' => 'Address',
    'broker_status' => 'Broker Status ',
    'acception_us_clients' => 'Accepting US Clients?',

    'account_currency'=>'Account Currency',
    'funding_withdrawl_method'=>'Funding Withdrawl Method',
    'swap_free_accounts'=>'Swap Free Accounts',
    'segregated_accounts'=>'Segregated Accounts',
    'interest_on_margin'=>'Interest On Margin',
    'managed_accounts'>'Managed Accounts',
    'accounts_for_money_managers'=>'Accounts For Money Managers',
    
    
    'phone'=>'Phone',
    'fax'=>'Fax',
    'email'=>'Email',
    'languages'=>'Languages',
    'availability'=>'Availability',
    
    
    'trading_platforms'=>'Trading Platforms',
    'trading_platform_timezone'=>'Trading Platform Timezone',
    'demo_account'=>'Demo Account',
    'mobile_trading'=>'Mobile Trading',
    'web_based_trading'=>'Web Based Trading',
    'api'=>'API',
    'oco_orders'=>' OCO Orders',
    'trading_over_the_phone'=>'Trading Over The Phone',
    'hedging_allowed'=>'Hedging Allowed',
    'trailing_stops'=>'Trailing Stops',
    'one_click_trading'=>'One Click Trading',
    'bonuses'=>'Bonuses',
    'contests'=>'Contests',
    'other_trading_instruments'=>'Other Trading Instruments',
    
    
    
    'minimum_deposit'=>'Minimum Deposit',
    'maximal_leverage'=>'Maximal Leverage',
    'minimum_lot_size'=>'Minimum Lot Size',
    'maximum_lot_size'=>'Maximum Lot Size',
    'commission'=>'Commission',
    'spread'=>'Spread',
    'decimals'=>'Decimals',
    'scalping_allowed'=>'Scalping Allowed',
    
    
    'description'=>'Description',
    'logo_url'=>'Logo',
    
    
    'account_options'=>'Account Options',
    'customer'=>'Customer',
    'trading'=>'Trading',
    'account'=>'Account',
    'description'=>'Description',
    
    ];