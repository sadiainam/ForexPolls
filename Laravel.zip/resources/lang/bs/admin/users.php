<?php

return [
    'users' => 'Korisnici',
    'name' =>   'Ime',
    'email' =>   'Email',
    'password' =>  'Lozinka',
    'password_confirmation' => 'Ponovljena lozinka',
    'activate_user' => 'Aktivan korisnik',
    'active_user' => 'Aktivan korisnik',
    'yes' => 'Da',
    'no' => 'Ne',
    'roles' => 'Uloge',
    'roles_info' => 'Dodavanjem uloga, korisniku se dodjeljuju sve privilegije za datu ulogu.'
];
