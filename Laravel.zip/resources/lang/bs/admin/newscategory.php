<?php

return [
    'newscategories' => 'Kategorije novosti',


];