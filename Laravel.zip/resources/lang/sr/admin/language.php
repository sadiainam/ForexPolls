<?php

return [
    'code' => 'Код',
    'icon' => 'Икона',
    'languages' => 'Језици',

];