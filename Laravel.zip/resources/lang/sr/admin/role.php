<?php

return [
    'roles' => 'Улоге',
    'adminrole' => 'Админ улоге',
    'userrole'  =>  'Корисничке улоге',
    'choose_role' =>   'Изаберите привилегије',
    'name'  => 'Назив',

];