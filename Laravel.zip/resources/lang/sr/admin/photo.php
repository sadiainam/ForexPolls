<?php

return [
    'photo' => 'Слике',
    'album' =>  'Албум',
    'album_cover' => 'Наслова слика',
    'slider' => 'Слајдер',
    'description' => 'Опис',
    'picture' => 'Слика',

];