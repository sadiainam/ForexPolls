<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateCommentsTable extends Migration {

    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up() {
        Schema::create('comments', function ($table) {
            $table->increments('id');
            $table->timestamps();
            $table->string('name');
            $table->string('email');
            $table->string('country');
            $table->integer('account');
            $table->enum('impression', array('positive', 'negative','neutral'));
            $table->string('review');
           $table->integer('broker_id')->unsigned();
           $table->foreign('broker_id')
      ->references('id')->on('brokers')
      ->onDelete('cascade');
           $table->softDeletes();
            
            
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down() {
        Schema::drop('comments');
    }

}
