<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateBrokerTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
          Schema::create('brokers', function (Blueprint $table) {
            $table->engine = 'InnoDB';
            $table->increments('id')->unsigned();
            $table->string('broker_name');
            $table->string('broker_type');
            $table->string('country');
            $table->integer('operating_year');
            $table->integer('no_of_employees');
            $table->enum('international_offices', array('USA', 'UK' ,'UAE'));
            $table->string('regulation');
            $table->string('address');
            $table->string('broker_status');
            $table->enum('acception_us_clients', array('yes', 'no'));
             
             
             $table->enum('account_currency', array('USD', 'GBP', 'EUR', 'CHF', 'JPY', 'NZD', 'CAD', 'SGD', 'HKD', 'AUD'));
             $table->enum('funding_withdrawl_method', array('Wire Transfer', 'Credit Card', 'Debit Card', 'Moneybookers', 'Neteller', 'UnionPay', 'Skrill', 'FasaPay'));
             $table->enum('swap_free_accounts', array('yes','no'));
             $table->enum('segregated_accounts', array('yes','no'));
             $table->enum('interest_on_margin', array('yes','no'));
             $table->enum('managed_accounts', array('yes','no'));
             $table->enum('accounts_for_money_managers', array('yes','no'));
             
             
             $table->integer('phone');
             $table->integer('fax');
             $table->string('email');
             $table->enum('languages', array('English', 'Russian', 'Mandarin', 'Chinese', 'Indonesian', 'Thai', 'Korean', 'Urdu', 'Hindi' ));
             $table->enum('availability', array('Phone', 'Chat', 'Email' ));
             
             
             $table->enum('trading_platforms', array('MetaTrader 4', 'cTrader', 'Web Platform', 'Mobile Platform' ));
             $table->enum('trading_platform_timezone', array('(GMT +2:00) South Africa', 'Jerusalem' ));
               $table->enum('demo_account', array('yes','no'));
               $table->enum('mobile_trading', array('yes','no'));
               $table->enum('web_based_trading', array('yes','no'));
               $table->enum('api', array('yes','no'));
               $table->enum('oco_orders', array('yes','no'));
               $table->enum('trading_over_the_phone', array('yes','no'));
               $table->enum('hedging_allowed', array('yes','no'));
               $table->enum('trailing_stops', array('yes','no'));
               $table->enum('one_click_trading', array('yes','no'));
               $table->enum('bonuses', array('yes','no'));
               $table->enum('contests', array('yes','no'));
               $table->enum('other_trading_instruments', array('Indices', 'Commodities', 'Energies', 'CFDs' ));
             
               
               $table->decimal('minimum_deposit',10,2);
               $table->integer('maximal_leverage');
               $table->decimal('minimum_lot_size',10,2);
               $table->decimal('maximum_lot_size',10,2);
               $table->decimal('commission',10,2);
               $table->string('spread');
               $table->string('decimals');
               $table->enum('scalping_allowed' , array('yes','no'));
             
               
               $table->longText('description');
               $table->string('logo_url');
             
            $table->timestamps();
            $table->softDeletes();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::drop('brokers');
    }
}
