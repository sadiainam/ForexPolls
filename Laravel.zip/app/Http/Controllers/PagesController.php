<?php

namespace App\Http\Controllers;

//use Illuminate\Http\Request;
//use App\View;
//use App\Rating;


use App\Broker;
use App\Comment;
use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\BrokerRequest;
use DB;
use Request;
use willvincent\Rateable\Rating;

class PagesController extends Controller {

    public function welcome() {
        return view('pages.welcome');
    }

    public function about() {
        return view('pages.about');
    }

    public function contact() {
        return view('pages.contact');
    }

    public function brokers() {
        $brokers = Broker::orderBy('id', 'DESC')->orderBy('created_at', 'DESC')->limit(4)->get();
        return view('pages.brokers', compact('brokers'));
    }

    public function show_broker(Request $request, $id) {

        $broker = Broker::find($id);
//        $platform = Rating::select(DB::raw("SUM(rating1) as count"))
//                        ->orderBy("created_at")
//                        // ->groupBy(DB::raw("year(created_at)"))
//                        ->get()->toArray();
//        //dd($viewer);
//        $platform = array_column($platform, 'count');
//        $pricing = Rating::select(DB::raw("SUM(rating2) as count"))
//                        ->orderBy("created_at")
//                        // ->groupBy(DB::raw("year(created_at)"))
//                        ->get()->toArray();
//        //dd($viewer);
//        $pricing = array_column($pricing, 'count');
//        //dd($viewer);
//        $customer_service = Rating::select(DB::raw("SUM(rating3) as count"))
//                        ->orderBy("created_at")
//                        //->groupBy(DB::raw("year(created_at)"))
//                        ->get()->toArray();
//        $customer_service = array_column($customer_service, 'count');
//        $feature = Rating::select(DB::raw("SUM(rating3) as count"))
//                        ->orderBy("created_at")
//                        //->groupBy(DB::raw("year(created_at)"))
//                        ->get()->toArray();
//        $feature = array_column($feature, 'count');
//        return view('pages.broker_view')
//                        ->with('platform', json_encode($platform, JSON_NUMERIC_CHECK))
//                        ->with('pricing', json_encode($pricing, JSON_NUMERIC_CHECK))
//                        ->with('customer_service', json_encode($customer_service, JSON_NUMERIC_CHECK))
//                        ->with('feature', json_encode($feature, JSON_NUMERIC_CHECK));
        return view('pages.broker_view', compact('$broker'));
    }

    public function rating(BrokerRequest $request) {

        $post = Broker::first();
        if (Request::ajax()) {

            $rating = new Rating;
            $rating->rating1 = $request->rate1;
            $rating->rating2 = $request->rate2;
            $rating->rating3 = $request->rate3;
            $rating->rating4 = $request->rate4;
            $rating->rating5 = $request->rate5;
            $rating->broker_id = $request->broker_id;
            $rating->user_id = 1; //\Auth::id();

            $post->ratings()->save($rating);
        }


        $platform = Rating::select(DB::raw("SUM(rating1) as count"))
                        ->orderBy("created_at")
                        ->groupBy(DB::raw("year(created_at)"))
                        ->get()->toArray();
        //dd($viewer);
        $platform = array_column($platform, 'count');
        $pricing = Rating::select(DB::raw("SUM(rating2) as count"))
                        ->orderBy("created_at")
                        ->groupBy(DB::raw("year(created_at)"))
                        ->get()->toArray();
        //dd($viewer);
        $pricing = array_column($pricing, 'count');
        //dd($viewer);
        $customer_service = Rating::select(DB::raw("SUM(rating3) as count"))
                        ->orderBy("created_at")
                        ->groupBy(DB::raw("year(created_at)"))
                        ->get()->toArray();
        $customer_service = array_column($customer_service, 'count');
        $feature = Rating::select(DB::raw("SUM(rating4) as count"))
                        ->orderBy("created_at")
                        ->groupBy(DB::raw("year(created_at)"))
                        ->get()->toArray();
        $feature = array_column($feature, 'count');
        $broker = Broker::find($request->broker_id);
        $comments = Comment::where('broker_id', $id)->get();
        //  dd($feature);
        return view('pages.broker_view')
                        ->with('platform', json_encode($platform, JSON_NUMERIC_CHECK))
                        ->with('pricing', json_encode($pricing, JSON_NUMERIC_CHECK))
                        ->with('customer_service', json_encode($customer_service, JSON_NUMERIC_CHECK))
                        ->with('feature', json_encode($feature, JSON_NUMERIC_CHECK))
                        ->with('comments', $comments)
                        ->with('broker', $broker);
//        return view('pages.broker_view', compact('$broker'));
    }

    public function highchart($id) {

        $platform = Rating::select(DB::raw("SUM(rating1) as count"))
                        ->orderBy("created_at")
                        // ->groupBy(DB::raw("year(created_at)"))
                        ->get()->toArray();
        $platform = array_column($platform, 'count');
        $pricing = Rating::select(DB::raw("SUM(rating2) as count"))
                        ->orderBy("created_at")
                        // ->groupBy(DB::raw("year(created_at)"))
                        ->get()->toArray();
        $pricing = array_column($pricing, 'count');
        $customer_service = Rating::select(DB::raw("SUM(rating3) as count"))
                        ->orderBy("created_at")
                        //->groupBy(DB::raw("year(created_at)"))
                        ->get()->toArray();
        $customer_service = array_column($customer_service, 'count');
        $feature = Rating::select(DB::raw("SUM(rating3) as count"))
                        ->orderBy("created_at")
                        //->groupBy(DB::raw("year(created_at)"))
                        ->get()->toArray();
        $feature = array_column($feature, 'count');
        $broker = Broker::find($id);
        $comments = Comment::where('broker_id', $id)->get();
        //dd($broker);
        return view('pages.broker_view')
                        ->with('platform', json_encode($platform, JSON_NUMERIC_CHECK))
                        ->with('pricing', json_encode($pricing, JSON_NUMERIC_CHECK))
                        ->with('customer_service', json_encode($customer_service, JSON_NUMERIC_CHECK))
                        ->with('feature', json_encode($feature, JSON_NUMERIC_CHECK))
                        ->with('comments', $comments)
                        ->with('broker', $broker);
    }

    public function comment_show() {
        //$countries = Countries::getList('en', 'json', 'cldr');
        //dd($countries);
        return view('pages.comment_form');
    }

    public function comment_add(BrokerRequest $request, $id) {
        if (Request::ajax()) {

            $comment = new Comment;
            $comment->name = $request->name;
            $comment->email = $request->email;
            $comment->account = $request->account;
            $comment->impression = $request->impression;
            $comment->country = $request->country;
            $comment->broker_id = $request->broker_id;
            $comment->review = $request->review;
//            $comment->user_id = 1; //\Auth::id();

            $comment->save();
        }
    }

    public function comparision($id_one, $id_two) {
        $broker_one = $this->return_broker_data($id_one);
        $broker_two =  $this->return_broker_data($id_two);
        $brokers_list = Broker::all();

        return view('pages.comparision')
                        ->with('broker_one', $broker_one)
                        ->with('broker_two', $broker_two)
                        ->with('brokers_list', $brokers_list);
    }
    
    public function return_broker_data($id){
//        dd( Broker::find($id));
        return Broker::find($id);
    }

}
