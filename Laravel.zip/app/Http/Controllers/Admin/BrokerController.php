<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\AdminController;
use App\Broker;
use App\Language;
use App\Http\Requests\Admin\BrokerRequest;
use Datatables;


class BrokerController extends AdminController
{
    
    public function __construct()
    {
        view()->share('type', 'broker');
    }
    
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        // Show the page
        return view('admin.broker.index');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
          $languages = Language::lists('name', 'id')->toArray();
          $broker_types = array();
          $broker_types [1] = 'STP';
          $broker_types [2] = 'ECN';
          $broker_types [3] = 'DMA';
          //dd($broker_types);
       // $articlecategories = ArticleCategory::lists('title', 'id')->toArray();
        return view('admin.broker.create_edit', compact('languages', 'articlecategories','broker_types'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(BrokerRequest $request)
    {
         $broker = new Broker();
        $broker->broker_name = $request->broker_name;
        $broker->broker_type = $request->broker_type;
        $broker->country = $request->country;
        $broker->operating_year = $request->operating_year;
        $broker->no_of_employees = $request->no_of_employees;
        $broker->international_offices = $request->international_offices;
        $broker->regulation = $request->regulation;
        $broker->address = $request->address;
        $broker->broker_status = $request->broker_status;
        $broker->acception_us_clients = $request->acception_us_clients;
        
        $broker->account_currency = $request->account_currency;
        $broker->funding_withdrawl_method = $request->funding_withdrawl_method;
        $broker->swap_free_accounts = $request->swap_free_accounts;
        $broker->segregated_accounts = $request->segregated_accounts;
        $broker->interest_on_margin = $request->interest_on_margin;
        $broker->managed_accounts = $request->managed_accounts;
        $broker->accounts_for_money_managers = $request->accounts_for_money_managers;
        
        
        $broker->phone = $request->phone;
        $broker->fax = $request->fax;
        $broker->email = $request->email;
        $broker->languages = $request->languages;
        $broker->availability = $request->availability;
        
        
        $broker->trading_platforms = $request->trading_platforms;
        $broker->trading_platform_timezone = $request->trading_platform_timezone;
        $broker->demo_account = $request->demo_account;
        $broker->mobile_trading = $request->mobile_trading;
        $broker->web_based_trading = $request->web_based_trading;
        $broker->api = $request->api;
        $broker->oco_orders = $request->oco_orders;
        $broker->trading_over_the_phone = $request->trading_over_the_phone;
        $broker->hedging_allowed = $request->hedging_allowed;
        $broker->trailing_stops = $request->trailing_stops;
        $broker->one_click_trading = $request->one_click_trading;
        $broker->bonuses = $request->bonuses;
        $broker->contests = $request->contests;
        $broker->other_trading_instruments = $request->other_trading_instruments;
        
        
        $broker->minimum_deposit = $request->minimum_deposit;
        $broker->maximal_leverage = $request->maximal_leverage;
        $broker->minimum_lot_size = $request->minimum_lot_size;
        $broker->maximum_lot_size = $request->maximum_lot_size;
        $broker->commission = $request->commission;
        $broker->spread = $request->spread;
        $broker->decimals = $request->decimals;
        $broker->scalping_allowed = $request->scalping_allowed;
        
        
        $broker->description = $request->description;
       
        $broker->save();
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        dd('$id');
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $broker = Broker::find($id);
        $languages = Language::lists('name', 'id')->toArray();
          $broker_types = array();
          $broker_types [1] = 'STP';
          $broker_types [2] = 'ECN';
          $broker_types [3] = 'DMA';
          
        return view('admin.broker.create_edit', compact('languages' ,'broker','broker_types'));
    
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(BrokerRequest $request, $id)
    {
        $broker = Broker::find($id); 
        $broker->broker_name = $request->broker_name;
        $broker->broker_type = $request->broker_type;
        $broker->country = $request->country;
        $broker->operating_year = $request->operating_year;
        $broker->no_of_employees = $request->no_of_employees;
        $broker->international_offices = $request->international_offices;
        $broker->regulation = $request->regulation;
        $broker->address = $request->address;
        $broker->broker_status = $request->broker_status;
        $broker->acception_us_clients = $request->acception_us_clients;
        
        $broker->account_currency = $request->account_currency;
        $broker->funding_withdrawl_method = $request->funding_withdrawl_method;
        $broker->swap_free_accounts = $request->swap_free_accounts;
        $broker->segregated_accounts = $request->segregated_accounts;
        $broker->interest_on_margin = $request->interest_on_margin;
        $broker->managed_accounts = $request->managed_accounts;
        $broker->accounts_for_money_managers = $request->accounts_for_money_managers;
        
        
        $broker->phone = $request->phone;
        $broker->fax = $request->fax;
        $broker->email = $request->email;
        $broker->languages = $request->languages;
        $broker->availability = $request->availability;
        
        
        $broker->trading_platforms = $request->trading_platforms;
        $broker->trading_platform_timezone = $request->trading_platform_timezone;
        $broker->demo_account = $request->demo_account;
        $broker->mobile_trading = $request->mobile_trading;
        $broker->web_based_trading = $request->web_based_trading;
        $broker->api = $request->api;
        $broker->oco_orders = $request->oco_orders;
        $broker->trading_over_the_phone = $request->trading_over_the_phone;
        $broker->hedging_allowed = $request->hedging_allowed;
        $broker->trailing_stops = $request->trailing_stops;
        $broker->one_click_trading = $request->one_click_trading;
        $broker->bonuses = $request->bonuses;
        $broker->contests = $request->contests;
        $broker->other_trading_instruments = $request->other_trading_instruments;
        
        
        $broker->minimum_deposit = $request->minimum_deposit;
        $broker->maximal_leverage = $request->maximal_leverage;
        $broker->minimum_lot_size = $request->minimum_lot_size;
        $broker->maximum_lot_size = $request->maximum_lot_size;
        $broker->commission = $request->commission;
        $broker->spread = $request->spread;
        $broker->decimals = $request->decimals;
        $broker->scalping_allowed = $request->scalping_allowed;
        
        
        $broker->description = $request->description;
       
        $broker->save();
        
    }
    
       /**
     * Remove the specified resource from storage.
     *
     * @param $id
     * @return Response
     */

    public function delete(Broker $broker)
    {
        // Show the page
        return view('admin/broker/delete', compact('broker'));
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
 public function destroy(Broker $broker)
    {
        $broker->delete();
    }
    
    /**
     * Show a list of all the languages posts formatted for Datatables.
     *
     * @return Datatables JSON
     */
    public function data()
	{
        
//        $language = Language:: whereNull('languages.deleted_at')
//           ->orderBy('languages.position', 'ASC')
//            ->select(array('languages.id', 'languages.name', 'languages.lang_code as lang_code','languages.lang_code as icon'));
//        return Datatables::of($language)
//            ->edit_column('icon', '<img src="blank.gif" class="flag flag-{{$icon}}" alt="" />')
//
//            ->add_column('actions', '<a href="{{{ URL::to(\'admin/language/\' . $id . \'/edit\' ) }}}" class="btn btn-success btn-sm iframe" ><span class="glyphicon glyphicon-pencil"></span> {{ trans("admin/modal.edit") }}</a>
//                    <a href="{{{ URL::to(\'admin/language/\' . $id . \'/delete\' ) }}}" class="btn btn-sm btn-danger iframe"><span class="glyphicon glyphicon-trash"></span> {{ trans("admin/modal.delete") }}</a>
//                    <input type="hidden" name="row" value="{{$id}}" id="row">')
//            ->remove_column('id')
//
//            ->make();
   
        $users = Broker::select(array('id', 'broker_name', 'broker_type', 'country'))->orderBy('id');
//dd($users);
        return Datatables::of($users)
            ->add_column('actions', '<a href="{{{ URL::to(\'admin/broker/\' . $id . \'/edit\' ) }}}" class="btn btn-success btn-sm iframe" ><span class="glyphicon glyphicon-pencil"></span>  {{ trans("admin/modal.edit") }}</a>
                    <a href="{{{ URL::to(\'admin/broker/\' . $id . \'/delete\' ) }}}" class="btn btn-sm btn-danger iframe"><span class="glyphicon glyphicon-trash"></span> {{ trans("admin/modal.delete") }}</a>
                ')
            ->remove_column('id')
            ->make();
    }
}
